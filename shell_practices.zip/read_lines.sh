#!/bin/bash

while read lines
do
	echo $lines
done < ./file1
