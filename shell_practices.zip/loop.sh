#!/bin/bash

for I in $(seq 1 10)
do
	echo "Loop is working"
done

