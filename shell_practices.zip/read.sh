#!/bin/bash
<< myname
read=`cat file1`
echo $read
myname


output=$(file1)
echo "$output"
