#!/bin/bash

x=54
y=89
z=62

echo ${x}
echo $y
echo ${z}

NAME="CHANDRA SAINAVA TEJA"
DESIGNATION="DEVOPS ENGINEER"

echo ${NAME}
echo ${DESIGNATION}
